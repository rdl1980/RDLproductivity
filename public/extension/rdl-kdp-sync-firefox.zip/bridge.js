// Content script on the app's pages: tells the app the extension is there
// and relays sync requests and their progress between page and background.
(() => {
  const api = globalThis.browser ?? globalThis.chrome;
  const version = api.runtime.getManifest().version;
  document.documentElement.dataset.rdlKdpExtension = version;
  window.dispatchEvent(new CustomEvent("rdl-kdp:ready", { detail: { version } }));

  window.addEventListener("message", (event) => {
    const data = event.data;
    if (event.source !== window || !data) return;
    // Hourly sync settings: get, set (config or null) and run now.
    if (data.type === "rdl-kdp:autosync") {
      api.runtime
        .sendMessage({ type: "autosync", action: data.action, config: data.config ?? null })
        .then(
          (reply) => reply ?? { error: "Nessuna risposta dall'estensione." },
          (error) => ({ error: String(error?.message ?? error) }),
        )
        .then((reply) =>
          window.postMessage(
            { type: "rdl-kdp:autosync-state", requestId: data.requestId, ...reply },
            location.origin,
          ),
        );
      return;
    }
    if (data.type !== "rdl-kdp:sync") return;
    api.runtime
      .sendMessage({
        type: "sync",
        requestId: data.requestId,
        steps: data.steps,
        options: data.options ?? {},
      })
      .catch((error) => {
        window.postMessage(
          {
            type: "rdl-kdp:done",
            requestId: data.requestId,
            error: String(error?.message ?? error),
          },
          location.origin,
        );
      });
  });

  api.runtime.onMessage.addListener((message) => {
    if (message && typeof message.type === "string" && message.type.startsWith("rdl-kdp:")) {
      window.postMessage(message, location.origin);
    }
  });
})();
